# PRODUCT MODEL

Experience -> Flow -> Stage -> Story Beat -> Mission -> Input -> Result -> Story Memory -> Narrative

Story Beat Lifecycle: Prepared -> Active -> Resolved

Mission = Interaction Pattern + Constraint + Input
