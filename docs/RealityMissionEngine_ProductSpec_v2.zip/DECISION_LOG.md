# DECISION LOG

- D010 Trigger-based Story Beat
- D011 Lifecycle
- D012 Stage owns Purpose
- D013 Player provides Input
- D014 Mission uses Interaction Pattern
- D015 Experience uses Flow
- Engine balances Experience rather than drives Story
