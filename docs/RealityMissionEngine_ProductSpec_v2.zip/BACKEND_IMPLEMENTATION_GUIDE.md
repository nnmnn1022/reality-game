# BACKEND IMPLEMENTATION GUIDE

Engine: Flow/Coverage/Stage/Progress
AI: Narrative, Input interpretation
Bot: Input collection
Story Curator: Event -> Memory -> Story Memory
