# PROJECT STATE

- Experience Engine
- AI = Narrative Director
- Engine = Experience Balancer
- Story는 플레이어가 만든다.
